/*
 * Developed by SPG Studios
 * http://www.spgstudios.com
 * Copyright (c) 2023.
 */
package com.yclash;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

public class License {
    public static final String NEVER = "never";
    public static final String LICENSE_FILE = "license.lic";
    public static final String EXPIRATION = "Expiration";
    private static final String SIGNATURE = "Signature";
    private List<String> names = new ArrayList<>();
    private Properties prop = new Properties();
    private String data = null;

    public void setFeature(String name, String value) {
        if (!this.names.contains(name)) {
            this.names.add(name);
        }

        this.prop.setProperty(name, value);
    }

    public String getExpiration() {
        return this.prop.getProperty("Expiration");
    }

    public void setExpiration(String date) {
        this.setFeature("Expiration", date);
    }

    public String getSignature() {
        return this.prop.getProperty("Signature");
    }

    public void setSignature(String signature) {
        this.setFeature("Signature", signature);
    }

    public String format() {
        StringBuffer buf = new StringBuffer();
        Iterator it = this.names.iterator();

        while(it.hasNext()) {
            String key = (String)it.next();
            if (key.length() != 0 && !key.equals("Signature")) {
                String value = UnicodeEncoder.encode(this.prop.getProperty(key));
                buf.append(key).append('=').append(value).append('\n');
            }
        }

        this.data = buf.toString();
        return this.data;
    }


    public void create() throws Exception {
        if (this.data != null && this.getSignature() != null) {
            FileWriter out = new FileWriter("license.lic");
            out.write(this.data);
            out.write(10);
            out.write("Signature");
            out.write(61);
            out.write(this.getSignature());
            out.flush();
            out.close();
        } else {
            throw new Exception("License is not formated ....");
        }
    }
}
