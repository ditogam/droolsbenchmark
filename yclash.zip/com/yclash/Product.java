/*
 * Developed by SPG Studios
 * http://www.spgstudios.com
 * Copyright (c) 2023.
 */
package com.yclash;

public enum Product {
    GC_WEB,
    GC_API,
    GC_DASH,
    FT_WEB,
    FT_API,
    HH_WEB,
    HH_API,
    YC;
}
