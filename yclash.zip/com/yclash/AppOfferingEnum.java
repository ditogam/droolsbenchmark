/*
 * Developed by SPG Studios
 * http://www.spgstudios.com
 * Copyright (c) 2023.
 */
package com.yclash;

public enum AppOfferingEnum {
    FREE,
    ENTERPRISE,
    ENTERPRISE_HOSTED,
    PRO,
    TRIAL;

    public static String FEATURE_1 = "Feature_1";
    public static String ENTERPRISE_PROPERTY = "enterprise";
}
