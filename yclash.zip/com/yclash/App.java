/*
 * Developed by SPG Studios
 * http://www.spgstudios.com
 * Copyright (c) 2023.
 */
package com.yclash;

public enum App {
    GC_EASY,
    FAST_THREAD,
    HEAP_HERO,
    RUN_METRICS,
    YC,
    YCC,
    YC_TOP,
    YC_ANSWERS,
    ACADEMY,
    NO_APP;
}
